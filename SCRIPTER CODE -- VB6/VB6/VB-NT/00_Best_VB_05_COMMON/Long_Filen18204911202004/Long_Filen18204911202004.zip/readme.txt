\\
Improfane's LongToShort File Name converter
by Improfane
--> If your text editor has word wrap, please turn it on for easier reading. If you do not know how to I suggest you look in Help or search it with Google (http://www.google.com/)
~~~
INSTRUCTIONS

About:
The application (that this should be included with) can convert to and from Long and Short filenames by either:
	- pasting a short or long file name
	- broswing for a file to turn a long file name into a short one

Microsoft DOS used short file names as it could not support more than a certain length of characters, this program and its modules can be useful if you want to use a file in DOS but has a longer than DOS supported file name.
The idea is that you convert the Windows compatitible filename to a dos file name or a 'short file name' for use in DOS applications.

Instructions: -
To convert a long file name to a short name that you have as a file on your computer:
	- Click 'Browse' and navigate to the desired file
		- If you have the long filename on your clipboard, click 'Paste' instead and then on the following context menu select 'Paste a Long Filename'
		- You can also simply TYPE the location of the long file name and click the 'Convert' button and select 'Convert Long to Short'
	- The short file name should have been generated and inserted into the second (short file name) box
		- To copy the short file name to clipboard, click 'Copy' and on the context menu select 'Copy Short Filename'

To convert a short file name to a long file name:
	- Type the short file name into the Short Filename box (the second box) - click the 'Convert' button and on the context menu select 'Convert Short to Long'
		- If you have the short filename location on your clipboard you can click  'Paste' and on the following context menu select 'Paste a Short Filename'
	- The long file name should have been generated and inserted into the first (long file name) box
		- To copy the long file name to clipboard, click 'Copy' and on the context menu select 'Copy Short Filename'

~~~
Credit/Legal Stuff:
Improfane/Vx3 are belong to Improfane, All rights reserved, 2004.
---> http://www.improfane.pwp.blueyonder.co.uk/
//