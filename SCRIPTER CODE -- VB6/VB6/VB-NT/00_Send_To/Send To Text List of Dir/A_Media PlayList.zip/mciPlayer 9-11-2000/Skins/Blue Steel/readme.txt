Blue Steel skin for WINAMP 2.x
------------------------------

just unzip in your /winamp/skin directory then select Blue Steel in the window 'select skin'.

Thanks for using this skin. I hope you'll find it useful.

if you have any comments or suggestions, contact me : stephane.feu@worldonline.fr


steph@ne - FRANCE