Author:       Juhana Uuttu aka Cthulhu
e-mail:       cthulhu@mbnet.fi or cthulhu@pp.htv.fi
Homepage:     http://www.mbnet.fi/~cthulhu/
Skin:         System Shock 2 (v1.3)
Release date: 21st of May 2000

Description:
------------
 "Tri-Optimum presents the next generation in cybernetic enhancements! Tri-Amp! Tri-Optimum Corp. will not be held responsible for injury while operating Tri-Amp under hazardous environment. Rock-rock!"

 This is actually my first skin - no, don't go! EVERYTHING is replaced: The mainwindow, playlist, equalizer and the minibrowser (and now the AVS). IMHO, I'm quite pleased with the results, but who wouldn't. :)

 And if you haven't tried System Shock 2 - do yourself a favour and support a great game by buying it. Or atleast get the demo. Thanks.

Thanks:
-------
 To the folks at www.sshock2.com and the bloke from Looking Glass Studios. (or was it Irrational? Damn that e-mail client for crashing. :P) And to the folk who commented my work. Thanks to them. Nice one.

How-to-install:
---------------
A)
 Stick this zip into your skins-directory

 -OR-

B)
 Create a directory called 'SystemShock2' in your skins-directory and unpack all the stuff into it.

 Acquire the skin from the menus of WinAmp - AND FALL TO THE AWESOME MIGHT OF OUR GODDESS SHODAN! BWAHAHAHAHAA!! ... Ahem.

History:
--------
v1.3 (21st of May 2000)

- 'Improved' the equalizer.
- Tried to make the positionbar more readable.
- Modified the minibrowser and playlist abit.
- Mainwindow and equalizer now have some indication if they're active or not.

v1.2 (13th of March 2000)

- Added the skin for the AVS.
- Err... that's it!

v1.1 (24th of January 2000)

- Reskinned the equalizer.
- Inserted a ':' in the mainwindow and put some text in those little buttons.
- Cleaning up some stuff in the Playlist.

v1.0 (13th of December 1999)

- Initial Release.
