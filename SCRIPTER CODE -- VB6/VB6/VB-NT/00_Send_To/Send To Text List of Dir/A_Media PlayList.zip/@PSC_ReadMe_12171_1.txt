Title: A MediaPlaylist BETA
Description: MediaPlaylist a set controls (volume, balance, playlist, position, timer, ...) that plays : AVI, CDA, DivX, MID, MP3, MPG, MOV, WAV. It has a MPG - MP3 tag editor and playlist editor (m3u & pls), Several kinds of sorting the playlist. Drag and Drop from Explorer into playlist. Add shortcuts for desired application. Playmode : Repeat 0,1, all, Shuffle or not. Support winamp skins (wsz not jet). Requires only MsFlxGrd.ocx and DivX code, it's a totaly replacement for the mci.ocx. (mciPlayer = Winamp Clone).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=12171&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
