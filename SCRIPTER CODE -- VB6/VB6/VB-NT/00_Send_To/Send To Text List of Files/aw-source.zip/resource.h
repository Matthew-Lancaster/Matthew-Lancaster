//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by gen_activewa.rc
//
#define IDS_PROJNAME                    100
#define IDD_MYDIALOG                    102
#define IDC_EDIT1                       201
#define IDR_APPLICATION                 201
#define IDC_EDIT2                       202
#define IDC_STOP                        203
#define IDD_RUNNING                     203
#define IDC_LIST1                       210
#define IDC_BUTTON1                     213
#define IDC_BUTTON2                     214
#define IDC_BUTTON3                     215
#define IDC_ARGS                        216
#define IDC_BUTTON4                     217

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         218
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
