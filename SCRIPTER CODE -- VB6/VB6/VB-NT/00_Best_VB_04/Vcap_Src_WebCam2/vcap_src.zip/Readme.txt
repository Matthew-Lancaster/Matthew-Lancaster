created on 12/02/98
updated on 06/02/00

'****************************************************************
'*  vbVidCap for Windows - Full source code for Visual Basic 5/6
'*  
'*  A full featured video capture application written entirely in
'*  Visual Basic. 
'*
'*  This program should be compatible with any Video For Windows 
'*  capture device.  Comments, suggestions, and bug reports can be
'*  sent to raymer@shrinkwrapvb.com
'*  
'*  More information and a fully compiled version of this program 
'*  is available at:
'*  http://www.shrinkwrapvb.com
'*
'*  Copyright (C) 1998-2000, Ray Mercer.  All rights reserved.
'****************************************************************


You may freely use and modify the source code contained in this 
product.  You may also freely distribute any application that uses this 
sample code or derivations thereof.  However, you may not redistribute 
any part of this archive or in any way derive financial gain from 
this sample without the express permission of it's author - Ray Mercer 
<raymer@shrinkwrapvb.com>

Use this product at your own risk!

Please see the licensing and distribution section of the Shrinkwrap
Visual Basic website for more information.

Copyright (c) 1998-2000, Ray Mercer all rights reserved

Another exclusive free product from Shrinkwrap Visual Basic(tm)!
http://www.shrinkwrapvb.com