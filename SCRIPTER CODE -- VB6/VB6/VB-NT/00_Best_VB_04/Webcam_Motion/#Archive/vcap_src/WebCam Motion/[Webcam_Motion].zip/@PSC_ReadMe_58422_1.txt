Title: [Webcam Motion Detection]
Description: This program captures from default camera and detects motion. Its very small code, and i commented all that wasnt common sense. Enjoy and vote =p
Side Note: In case your camera doesnt work too good or properly, start up Movie Maker and it will detect the camera and add it to cameras connected list in windows... then you can use it for sure... sometimes this happens
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58422&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
