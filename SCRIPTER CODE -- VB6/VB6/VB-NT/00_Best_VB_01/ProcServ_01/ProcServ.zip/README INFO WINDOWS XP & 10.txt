---------------------------------------------------------------------
\\1-asus-x5dij\1_asus_x5dij_01_c_drive\WINDOWS\system32\wbem\wbemads.tlb
---------------------------------------------------------------------

WHEN GO TO RUN THIS PROJECT
ERROR HAPPEN WHILE WINDOWS 10
BUT USED TO RUN FINE WINDOWS XP

THIS DRIVER I FETCH FROM MY XP COMPUTER

wbemads.tlb

YOU ABLE TO ONLY IF WANT DO PLACE IN 
\WINDOWS\system32\wbemads.tlb

THAT IS ALL 
OR MAYBE USE IN CURRENT FOLDER

---------------------------------------------------------------------
I WANT THIS PROJECT IN STRIPPER 
TO GIVE SYSTEM START TIME
NOT THE TICK CLOCKER TIME
BECAUSE SOMETIME THAT IS ERROR LARGE NUMBER OVER A MONTH
REQUIRE HANDLE PROPER

BETTER GET SYSTEM START TIME
AND DO THE MATH FROM THERE

AND ALSO SYSTEM INSTALL DATE ANOTHER ONE USEFUL
---------------------------------------------------------------------

---------------------------------------------------------------------
[ Sunday 20:40:00 Pm_17 March 2019 ]
---------------------------------------------------------------------