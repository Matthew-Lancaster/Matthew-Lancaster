Title: Suspend Process/Thread
Description: This program can suspend/resume any process. To suspend the process the program simply enumerates all the threads of the process and suspends them. The enumerations are global and they are done with the ToolHelp APIs. OpenThread works only on windows ME/2000/XP. ToolHelp apis are not defined only on Windows NT.
keywords:OpenThread,thread handle,Enumerating threads,Suspend Process,SuspendThread,ToolHelp Apis,stop process,pause process,stop thread

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=65354&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
