int stopsearch(void)
{
    return(0);
}
