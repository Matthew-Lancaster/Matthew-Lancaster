Title: [ Fill non-Regular polygons ] - Multiple Patterns included
Description: This is a 'Fill Region' function which is made on a request from PSC. I uploaded this code inorder to get usefull to someone else too.This is a very useful code for all who engaged in VB drawing programs.You only need to give the vetieces of the polygon. This function can fill a specified regular/irregular regions with any color/pattern.The bitmap pallate shading is also included. This is an API shading and is very fast and efficient. You can specify the all eight Fillstyles. Feel free to send feedbacks and suggessions. Good Luck!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58667&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
