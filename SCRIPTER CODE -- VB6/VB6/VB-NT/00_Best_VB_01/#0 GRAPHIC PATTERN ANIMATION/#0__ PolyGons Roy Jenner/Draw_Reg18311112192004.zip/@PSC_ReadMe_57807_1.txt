Title: [ Draw Regular Filled Polygon ] - An Ultimate Solution.
Description: This is a 'Draw Polygon' function which can draw a regular-filled Polygon with advanced filling options like 'Filling Bitmap Pattern' .The main importance of this code is that, you need only to specify the 'Side-length' and 'SideLength'.It is not needed to specify all the verticies included. It can draw unlimited sides and can 'Rotate' the polygon about the centre as well as the specified vertex.You can specify the filling color by setting the "FillColor' of the PictureBox. It works smooth and fast. It contains some equations which derived myself.
The 'New Feature' of this update is it's better nine 'Filliling Options'
 1. Transparent 
 2. HorizontalLine
 3.VerticalLine 
 4. UpwardDiagonal 
 5.DownwardDiogonal 
 6.Cross 
 7.DiagonalCross 
 8. Solid 
 9.FillBitmap 
Its Upto you to Vote for this code. Anyway please don't forget to add your Comments/Feedbacks. Good Luck!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=57807&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
