----------------------------------------------------------
                  DXFWriter.dll v.1.0 
----------------------------------------------------------
DXFWriter is an object oriented ActiveX DLL for generating 
DXF files.

Features: 
- Drawing objects: Lines, Points, Circles, Ellipses, Texts, 
  Polylines, Arcs, Solids, Linear dimensions, angular 
  dimensions, linear hatch, regular polygons, 
  rectangles.
- Line styles, fonts, colors, layers.
----------------------------------------------------------
                � 2006, Athanasios Gardos
e-mail: gardos@hol.gr            
You may freely use, modify and distribute this source code

Last update: November 16, 2006

Please visit:
     http://business.hol.gr/gardos/
or
     http://avax.invisionzone.com/
for development tools and more source code
-----------------------------------------------------------