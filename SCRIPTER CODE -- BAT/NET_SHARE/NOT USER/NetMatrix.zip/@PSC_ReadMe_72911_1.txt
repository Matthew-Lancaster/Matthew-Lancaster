Title: NetMatrix
Description: NetMatrix v1.6 | The Net Analyzer
1. What is NetMatrix? NetMatrix is a tool to help you analyze your network/LAN or even Internet. It has so many tools inside like port scanner, port sweeper, pinger, etc.
2. License. NetMatrix is freeware, free distributable, free copy, and free of charge.
3. Credits. Thanks to all of my friends who support me, my family, all tester, vbcode.com, planet-source-code.com, and you.
4. Contact
Author: Idrus Fhadli aka xvader
E-mail: fadly87@gmail.com
URL: http://idrus.net
Copyright (C) 2004/2005 - 2009, NeverHard!
Copyleft 2010, Sriwijaya-Empire.com | Now it apply the GNU General Public License version 2
Enjoy!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72911&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
