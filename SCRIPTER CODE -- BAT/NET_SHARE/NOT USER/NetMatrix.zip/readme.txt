NeverHard!
==========
Proudly presents
----------------

NetMatrix v1.6
==============
The Net Analyzer
----------------

Brought to you by:
------------------
NeverHard! Software Distribution Division
-----------------------------------------

Table of Contents:
==================
1. What is Metmatrix?
2. License
3. Credits
4. Contacts

===================================================================

1. What is NetMatrix?
---------------------
NetMatrix is a tool to help you analyze your network/LAN or even Internet. It has so many tools inside like port scanner, port sweeper, pinger, etc.

2. License
----------
NetMatrix is freeware, free distributable, free copy, and free of charge.

3. Credits
----------
Thanks to all of my friends who support me, my family, all tester, vbcode.com, planet-source-code.com, and you.

4. Contacts
-----------
Author: Idrus Fhadli aka xvader

E-mail:
- fadly87@gmail.com

URL:
http://idrus.net

Copyright (C) 2004/2005 - 2009, NeverHard!
Copyleft 2010, Sriwijaya-Empire.com | Now it apply the GNU General Public License version 2

Thanks for reading further...
Enjoy!!!

EOF