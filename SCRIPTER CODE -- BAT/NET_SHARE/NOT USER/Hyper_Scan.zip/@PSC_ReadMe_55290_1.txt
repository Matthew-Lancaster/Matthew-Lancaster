Title: Hyper Scanner 1.0 port scanner
Description: This is designed to be a fast(er) port scanner, configurable (pipelines, timeouts) and automatic (scans Class D or C level ranges). It uses Winsock arrays to make pipelines to test ports. Works very well on a LAN, and has good to excellent success on the Internet, in my testing anyways. The code demonstrates using arrays of controls, etc. This is my first submission to PSCode.com, please enjoy!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55290&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
