// stdafx.cpp : Quelldatei, die nur die Standard-Includes einbindet.
// ShellExtension.pch ist der vorkompilierte Header.
// stdafx.obj enth�lt die vorkompilierten Typinformationen.

#include "stdafx.h"
